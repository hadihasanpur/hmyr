<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSectionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('sections', function (Blueprint $table) {
            $table->id();
            $table->string('name')->comment('نام واحد');
            $table->string('inferior_to')->comment('نام واحد تحت امر');
            $table->mediumText('description')->nullable()->comment('توضیحات');
            $table->char('tel1', 15)->nullable()->comment('تلفن مستقیم');
            $table->char('tel2', 4)->nullable()->comment('تلفن داخلی');
            $table->char('fax', 10)->nullable()->comment('فکس');
            $table->string('email')->nullable()->comment('ایمیل');
            $table->string('address')->nullable()->comment('آدرس واحد');
            $table->unsignedTinyInteger('priority')->comment('ترتیب منو');
            $table->string('slug')->unique();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('sections');
    }
}
