-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 11, 2022 at 03:28 PM
-- Server version: 10.3.34-MariaDB-cll-lve
-- PHP Version: 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hmyr_hamyardb`
--

-- --------------------------------------------------------

--
-- Table structure for table `links`
--

CREATE TABLE `links` (
  `id` int(11) NOT NULL,
  `name` char(45) COLLATE utf8_persian_ci NOT NULL,
  `link` char(40) COLLATE utf8_persian_ci DEFAULT NULL,
  `link_group` char(15) COLLATE utf8_persian_ci NOT NULL,
  `order` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci;

--
-- Dumping data for table `links`
--

INSERT INTO `links` (`id`, `name`, `link`, `link_group`, `order`) VALUES
(1, 'خبرگزاری فارس', 'https://www.farsnews.ir/', 'خبرگزاری', 1),
(2, 'خبرگزاری جمهوری اسلامی(ایرنا)', 'https://www.irna.ir/', 'خبرگزاری', 2),
(3, 'خبرگزاری دانشجویان ایران(ایسنا)', 'http://www.isna.ir/', 'خبرگزاری', 3),
(4, 'خبرگزاری مهر', 'https://www.mehrnews.com/', 'خبرگزاری', 8),
(5, 'خبرگزاری تسنیم', 'https://www.tasnimnews.com/', 'خبرگزاری', 7),
(6, 'واحد مرکزی خبر', 'https://www.iribnews.ir/', 'خبرگزاری', 7),
(7, 'خبرگزاری میزان', 'https://www.mizanonline.com/', 'خبرگزاری', NULL),
(8, 'خبرگزاری کار ایران(ایلنا)', 'https://www.ilna.news/', 'خبرگزاری', NULL),
(9, 'خبرگزاری برنا', 'https://www.borna.news/', 'خبرگزاری', NULL),
(10, 'خبرگزاری بین المللی قرآن', 'https://iqna.ir/fa', 'خبرگزاری', NULL),
(11, 'خبرگزاری ورزش ایران(ایپنا)', 'http://www.ipna.ir/', 'خبرگزاری', NULL),
(12, 'سایت خبری تحلیلی فناوری اطلاعات و ارتباطات', 'https://www.itna.ir/', 'خبرگزاری', NULL),
(13, 'خبرگزاری آریا', 'http://www.aryanews.com/', 'خبرگزاری', NULL),
(14, 'خبرگزاری مجلس شورای اسلامی', 'https://www.icana.ir/Fa/', 'خبرگزاری', NULL),
(15, 'خبرگزاری موج', 'https://www.mojnews.com/#gsc.tab=0', 'خبرگزاری', NULL),
(16, 'خبرگزاری نسیم', 'https://www.nasimonline.ir/', 'خبرگزاری', NULL),
(17, 'خبرگزاری علم و فن آوری', 'http://www.stnews.ir/', 'خبرگزاری', NULL),
(18, 'فرمانداری ارومیه', 'https://www.urmia-ag.ir/fa/home/index', 'فرمانداری', NULL),
(19, 'فرمانداری اشنویه', 'http://www.oshnavieh-ag.ir/fa/home/index', 'فرمانداری', NULL),
(20, 'فرمانداری بوکان', 'https://www.bookan-ag.ir/fa/home/index', 'فرمانداری', NULL),
(21, 'فرمانداری سلماس', 'http://www.salmas-ag.ir/fa/home/index', 'فرمانداری', NULL),
(22, 'فرمانداری خوی', 'http://www.khoy-ag.ir/fa/home/index', 'فرمانداری', NULL),
(23, 'فرمانداری مهاباد', 'http://www.mohabad-ag.ir/fa/home/index', 'فرمانداری', NULL),
(24, 'فرمانداری میاندوآب', 'http://www.miandoab-ag.ir/fa/home/index', 'فرمانداری', NULL),
(25, 'فرمانداری ماکو', 'http://www.makoo-ag.ir/fa/home/index', 'فرمانداری', NULL),
(26, 'فرمانداری نقده', 'http://www.nagadeh-ag.ir/fa/home/index', 'فرمانداری', NULL),
(27, 'فرمانداری پلدشت', 'http://www.poldasht-ag.ir/fa/home/index', 'فرمانداری', NULL),
(28, 'فرمانداری پیرانشهر', 'http://www.piranshahr-ag.ir/fa/home/inde', 'فرمانداری', NULL),
(29, 'فرمانداری تکاب', 'http://www.tekab-ag.ir/fa/home/index', 'فرمانداری', NULL),
(30, 'فرمانداری سردشت', 'http://www.sardasht-ag.ir/fa/home/index', 'فرمانداری', NULL),
(31, 'فرمانداری شاهیندژ', 'http://www.shahindezh-ag.ir/fa/home/inde', 'فرمانداری', NULL),
(32, 'فرمانداری شوط', 'http://www.shout-ag.ir/fa/home/index', 'فرمانداری', NULL),
(33, 'فرمانداری چالدران', 'https://www.chalderan-ag.ir/fa/home/inde', 'فرمانداری', NULL),
(34, 'فرمانداری چایپاره', 'http://www.chaypareh-ag.ir/fa/home/index', 'فرمانداری', NULL),
(35, 'سازمان همیاری استان اصفهان', 'http://www.hmesf.ir/', 'همیاری ها', NULL),
(37, 'سازمان همیاری  استان آذربایجان شرقی', 'http://www.hamyaritabriz.ir/', 'همیاری ها', NULL),
(38, 'سازمان همیاری استان خراسان رضوی', 'https://www.hamyari-kh.ir/default.aspx', 'همیاری ها', NULL),
(39, 'سازمان همیاری استان خراسان جنوبی', 'http://www.sk-hrm.ir/', 'همیاری ها', NULL),
(40, 'سازمان همیاری استان البرز', 'http://www.sk-hrm.ir/', 'همیاری ها', NULL),
(41, 'سازمان همیاری استان خوزستان', 'http://www.hamyarikhouz.ir/', 'همیاری ها', NULL),
(42, 'سازمان همیاری استان کرمانشاه', 'http://hamyari-ksh.ir/', 'همیاری ها', NULL),
(43, 'سازمان همیاری استان مرکزی', 'https://hamyari-mr.ir/', 'همیاری ها', NULL),
(44, 'سازمان همیاری استان هرمزگان', 'http://www.hamyarih.ir/', 'همیاری ها', NULL),
(45, 'سازمان همیاری استان قزوین', 'http://hamyari-qazvin.ir/', 'همیاری ها', NULL),
(46, 'سازمان همیاری شهرداریهای استان چهار محال بختی', 'http://sh-chb.ir/', 'همیاری ها', NULL),
(47, 'سازمان همیاری استان قم', 'http://www.hamyariqom.com/', 'همیاری ها', NULL),
(48, 'سازمان همیاری استان قم', 'http://ww1.hamyariqom.com/', 'همیاری ها', NULL),
(49, 'سازمان همیاری استان گیلان', 'http://hamyariguilan.org/', 'همیاری ها', NULL),
(50, 'سازمان همیاری شهرداریهای استان کرمان', 'http://hamyarikerman.ir/', 'همیاری ها', NULL),
(51, 'سازمان همیاری شهرداریهای استان سمنان', 'http://semnan-hamyar.org/', 'همیاری ها', NULL),
(52, 'سازمان همیاری استان کردستان', 'http://www.hamyarikd.com/', 'همیاری ها', NULL),
(53, 'پایگاه اطلاع رسانی دفتر مقام معظم رهبری', 'https://www.leader.ir/', 'مهم', NULL),
(54, 'پایگاه اطلاع رسانی ریاست جمهوری', 'http://www.president.ir/', 'مهم', NULL),
(55, 'پایگاه اطلاع رسانی دولت', 'http://dolat.ir/', 'مهم', NULL),
(56, 'پرتال خبری وزارت کشور', 'https://www.moi.ir/', 'مهم', NULL),
(57, 'استانداری آذربایجان غربی', 'http://www.ostan-ag.gov.ir/fa/home/index', 'مهم', NULL),
(58, 'سامانه ابلاغ الکترونیک قضایی', 'https://adliran.ir/Home/SelectLink/2', 'مهم', NULL),
(59, 'درگاه خدمات الکترونیک قضایی', 'https://eblagh.adliran.ir/Home/Index', 'مهم', NULL),
(60, 'پایگاه اطلاع رسانی قوه قضاییه', 'http://www.dadiran.ir/', 'خبرگزاری', NULL),
(61, 'پایگاه اطلاع رسانی ارتش جمهوری اسامی ایران', 'https://www.aja.ir/portal/home/', 'خبرگزاری', NULL),
(62, 'جام جم', 'https://jamejamonline.ir/', 'روزنامه', NULL),
(63, 'حمایت', 'http://www.hemayat.net/', 'روزنامه', NULL),
(64, 'روزنامه رسالت', 'https://resalat-news.com/', 'روزنامه', NULL),
(65, 'روزنامه عصرایرانیان', 'http://www.asre-iranian.ir/', 'روزنامه', NULL),
(66, 'روزنامه هفت صبح', 'https://7sobh.com/', 'روزنامه', NULL),
(67, 'روزنامه ابتکار', 'http://www.ebtekarnews.com/', 'روزنامه', NULL),
(68, 'روزنامه آفرینش', 'http://iranpress.ir/Afarinesh/afarinesh/', 'روزنامه', NULL),
(69, 'روزنامه سیاست روز', 'http://www.siasatrooz.ir/', 'روزنامه', NULL),
(70, 'روزنامه کیهان', 'http://kayhan.ir/fa', 'روزنامه', NULL),
(71, 'روزنامه اطلاعات', 'https://www.ettelaat.com/', 'روزنامه', NULL),
(72, 'روزنامه دنیای اقتصاد', 'https://donya-e-eqtesad.com/', 'روزنامه', NULL),
(73, 'روزنامه وطن امروز', 'http://vatanemrooz.ir/', 'روزنامه', NULL),
(74, 'پایگاه خبری تحلیلی 598', 'http://www.598.ir/', 'خبرگزاری', NULL),
(75, 'پایگاه خبری افکارنیوز', 'https://www.afkarnews.com/', 'خبرگزاری', NULL),
(76, 'خبرگزاری تحلیلی خبرآنلاین', 'https://www.khabaronline.ir/', 'خبرگزاری', NULL),
(77, 'خبرگزاری اقتصاد ایران', 'http://econews.ir/', 'خبرگزاری', NULL),
(78, 'جامعه خبری تحلیلی للف', 'https://www.alef.ir/', 'خبرگزاری', NULL),
(79, 'پایگاه تحلیلی خبری انتخاب', 'https://www.entekhab.ir/', 'خبرگزاری', NULL),
(80, 'پایگاه مطالعات استراتژیک برنامه هسته ای ایران', 'http://www.irannuc.ir/', 'خبرگزاری', NULL),
(81, 'پایگاه خبری آفتاب', 'https://aftabnews.ir/', 'خبرگزاری', NULL),
(82, 'باشگاه خبرنگاران جوان', 'https://www.yjc.ir/', 'خبرگزاری', 4),
(83, 'پایگاه خبری تحلیلی بصیرت', 'https://basirat.ir/', 'خبرگزاری', NULL),
(84, 'سایت خبری تحلیلی بولتن نیوز', 'https://www.bultannews.com/', 'خبرگزاری', NULL),
(85, 'سایت خبری تحلیلی پارس نیوز', 'https://www.parsnews.com/', 'خبرگزاری', NULL),
(86, 'پایگاه خبری تحلیلی پارسینه', 'https://www.parsnews.com/', 'خبرگزاری', NULL),
(87, 'سایت خبری تابناک', 'https://www.tabnak.ir/', 'خبرگزاری', NULL),
(88, 'تاریخ ایرانی', 'http://tarikhirani.ir/fa', 'خبرگزاری', NULL),
(89, 'همشهری آن لاین', 'https://www.hamshahrionline.ir/', 'خبرگزاری', 5),
(90, 'روزنامه همشهری', 'https://media.hamshahrionline.ir/d/f/ham', 'روزنامه', NULL),
(91, 'پایگاه اطلاع رسانی جماران', 'https://www.jamaran.news/', 'خبرگزاری', NULL),
(92, 'خبرگزاری دانشجو', 'https://snn.ir/', 'خبرگزاری', NULL),
(93, 'خیبر آنلاین', 'http://kheybaronline.ir/', 'خبرگزاری', NULL),
(94, 'شبکه اطلاع رسانی دانا', 'https://www.dana.ir/', 'خبرگزاری', NULL),
(95, 'سایت دپلماسی ایرانی', 'http://www.irdiplomacy.ir/fa', 'خبرگزاری', NULL),
(97, 'رجل نیوز', 'http://www.rajanews.com/', 'خبرگزاری', NULL),
(98, 'پایگاه خبری سپاه پاسداران انقلاب اسلامی ایران', 'http://www.sepahnews.com/', 'خبرگزاری', NULL),
(99, 'پایگاه خبری تحلیلی سینمای ایران', 'https://cinemafa.com/', 'خبرگزاری', NULL),
(100, 'شبکه اطلاع رسانی نفت و انرژی شانا', 'https://www.shana.ir/', 'خبرگزاری', NULL),
(101, 'اپایگاه تحلیلی خبری شفاف', 'http://www.shafaf.ir/', 'خبرگزاری', NULL),
(102, 'پایگاه خبری تحلیلی شهدای ایران', 'http://shohadayeiran.com/', 'خبرگزاری', NULL),
(103, 'پایگاه خبری تحلیلی صراط', 'https://www.seratnews.com/', 'خبرگزاری', NULL),
(104, 'سایت خبری تحلیلی عصر امروز', 'http://asremrooz.ir/', 'خبرگزاری', NULL),
(105, 'سایت خبری تحلیلی عصر امروز', 'https://www.asriran.com/', 'خبرگزاری', NULL),
(106, 'پایگاه خبری-تحلیلی فرارو', 'https://fararu.com/', 'خبرگزاری', NULL),
(107, 'پایگاه خبری تحلیلی فردا', 'https://www.fardanews.com/', 'خبرگزاری', NULL),
(108, 'پایگاه اطلاع رسانی فرهنگ علوم انسانی', 'http://farhangemrooz.com/', 'خبرگزاری', NULL),
(109, 'ورزش 3', 'https://www.varzesh3.com/', 'خبرگزاری', 6),
(110, 'سایت خبری تحلیلی ساعت ۲۴', 'https://www.saat24.news/', 'خبرگزاری', NULL),
(111, 'شركت مديريت فناوری بورس تهران', 'http://www.tsetmc.com/Loader.aspx?ParTre', 'مهم', NULL),
(112, 'سازمان شهرداری ها و دهیاری های کشور', 'http://imo.org.ir/', 'مهم', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `links`
--
ALTER TABLE `links`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `links`
--
ALTER TABLE `links`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=113;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
