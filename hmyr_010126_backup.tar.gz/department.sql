-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 11, 2022 at 03:27 PM
-- Server version: 10.3.34-MariaDB-cll-lve
-- PHP Version: 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hmyr_hamyardb`
--

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `code` int(11) NOT NULL,
  `title` mediumtext COLLATE utf32_persian_ci NOT NULL,
  `content` text COLLATE utf32_persian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_persian_ci;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`code`, `title`, `content`) VALUES
(1, '<p><span style=\"font-family: BB;\">معاونت فنی و مهندسی سازمان همیاری شهرداریهای استان آذربایجان غربی</span></p>', '<p style=\"text-align: justify;\">&nbsp;</p>\r\n<p style=\"text-align: justify;\"><span style=\"font-family: BB; font-size: 16px;\">براســــاس شرح وظایفی که در اساسنامه سازمان برای معاونت فنی و مهندسی در نظر گرفته شده کلیه کارهای عمرانی به شرح زیر در توان و صلاحیت تخصصی این واحد می باشــــد.</span></p>\r\n<ul style=\"text-align: justify;\">\r\n<li><span style=\"font-family: BB; font-size: 16px;\"> اجرای راهسازی، زیر سازی راه آهن و باند فرودگاه</span></li>\r\n<li><span style=\"font-family: BB; font-size: 16px;\"> اجرای پل سازی</span></li>\r\n<li><span style=\"font-family: BB; font-size: 16px;\"> اجرای شبکه های ابیاری و زهکشی</span></li>\r\n<li><span style=\"font-family: BB; font-size: 16px;\"> احداث طرحهای آبخیزداری</span></li>\r\n<li><span style=\"font-family: BB; font-size: 16px;\"> احداث پارکها و مراکز تفریحی</span></li>\r\n<li><span style=\"font-family: BB; font-size: 16px;\"> احداث مجتمع های ساختمانی</span></li>\r\n</ul>\r\n<p style=\"text-align: justify;\"><span style=\"font-family: BB; font-size: 16px;\">معاونت فنی و اجرایی سازمان همیاری شهرداریهای استان آذربایجانغربی با سابقه 20 ساله در اجرای پروژه های عمرانی و با برخورداری از کارشناسان و مهندسین مجرب و با جلب مشارکت مهندسین مشاور و امکانات بالای ماشین آلات خود توانایی آن را داشته که تعداد زیادی از پروژه های بزرگ راهسازی، ابنیه و شبکه های آبیاری و زهکشی را اجرا نماید.</span></p>\r\n<p>&nbsp;</p>\r\n<p style=\"text-align: justify;\"><span style=\"font-family: BB; font-size: 16px;\">انجام عمليات پيمانكاري در رشته كارهاي عمومي نظير ، زيرسازي و يا روسازي راه و خيابان ، زيرسازي راه آهن و عمليات ساختماني مترو باند و محوطه فرودگاه ، پل ، تونل ، ديوار ساحلي ، محوطه سازه ي بندر و ساحل ، شمع كوبي و سپر كوبي، ساختمان ،كانال و نهر و زهكشي ، بند ، سيل برگردان ، تسطيح و آماده سازي اراضي براي مصارف گوناگون و كارهاي مشابه </span></p>\r\n<p style=\"text-align: justify;\"><span style=\"font-family: BB; font-size: 16px;\">انجام عمليات پيمانكاري در رشته تاسيسات شهري مانند آب و فاضلاب ( اعم از سطحي يا منازل يا صنعتي ) گازشهري ، برق رساني ، مخابرات ، انتقال آب ، ساختمان تاسيسات آبگيري و تصفیه خانه هاي آب و فاضلاب و تله كابين و كارهاي مشابه </span></p>\r\n<p style=\"text-align: justify;\"><span style=\"font-family: BB; font-size: 16px;\">انجام عمليات پيمانكاري دررشته ابنيه مانند، ساختمان ابنيه عمومي ، مسكن، ابنيه درماني بهداشتي ، ابنيه آموزشي و فرهنگي و&nbsp; ورزشي ، ترمينال هاي مسافري با عملكرد درون شهري و برون شهري ، ايستگاههاي آتش نشاني و امداد ، ميادين ميوه و تره بار و خريد و فروش مايحتاج عمومي ، پاركينگ هاي&nbsp; سطحي و طبقاتي و احداث پاركها و باغهاي شهري و گردشگاههاي كوهستاني وجنگلي و ساحلي </span></p>\r\n<p style=\"text-align: justify;\"><span style=\"font-family: BB; font-size: 16px;\">انجام عمليات پيمانكاري در رشته تاسيسات گرم كننده و خنك كننده ، برقي ، بيمارستاني ، آزمايشگاهي و كارهاي مشابه</span></p>\r\n<p style=\"text-align: justify;\"><span style=\"font-family: BB; font-size: 16px;\">انجام عمليات پيمانكاري در رشته اختصاصي نظير تزريق سيمان با مواد ديگر ، حفر چاه عميق ، لايروبي ، سدسازي ، مخازن بتني و فلزي. </span></p>'),
(2, '<p>درباره ما</p>', '<p>وو.</p>');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`code`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
